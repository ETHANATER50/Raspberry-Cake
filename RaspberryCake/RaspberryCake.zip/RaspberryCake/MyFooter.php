
<br/>
<br/>
<br/>
<hr/>


<?php
$CurrentYear = 2022;
echo "Raspberry Bakery - Copyright The Raspberry Guys " . $CurrentYear;
?>

</body>
</html>

