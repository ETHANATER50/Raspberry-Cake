<?php
require "MyHeader.php";
?>

<br />
<div id="body">
    <h1>Contact Us!</h1>
    <br />
    <b>
        <h2>Our Email: RaspberryBakery@loremipsum.com</h2>
        <h2>Our Phone Number: (666)555-Raspberry</h2>
    </b>
    <br />
    <br />
</div>

<?php
require "MyFooter.php";
?>