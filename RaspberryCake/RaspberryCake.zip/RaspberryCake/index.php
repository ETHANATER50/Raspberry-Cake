<?php
require "MyHeader.php";
?>

<br />
<!DOCTYPE html>
<html>

    <head>
        <!--<link rel="stylesheet" href=/>-->
    </head>
    <body>
        <div id="body">
            <h1>Welcome To The Raspberry Bakery!</h1>
            <h2>It's our mission to create the perfect raspberry taste! Join us in our journey into raspberry nirvana!</h2>
            <img src="Images/1.png" alt="2" id="image"/>

            <b>
                <p>Bear witness to one of our most beautiful creations: The Raspberry Cookie!</p>
                <p>Complete with our stamp of approval!</p>
            </b>
            <br />
            <br />
    </div>
    </body>
</html>
<?php
require "MyFooter.php";
?>
