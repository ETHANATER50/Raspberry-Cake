<?php
require "MyHeader.php";
?>

<br />
<div id="body">
    <h1>About Our Raspberry Mission:</h1>
    <br />
    <b>
        <h2>We are a purely rasberry operation. All of our good consist of raspberry based ingredients in order to meet our ultimate goal: to make the perfect raspberry taste.</h2>
        <h2>Before you ask, no. We do no make Raspberry Pies. These are blasphemous, and a slight against the good name of raspberries.</h2>
        <h2>If you'd like to see our products, check out the product page! We have plenty of raspberry based goods wating for you. Join us on our journey to raspberry nirvana!</h2>
    </b>
    <br />
    <br />
</div>
<?php
require "MyFooter.php";
?>