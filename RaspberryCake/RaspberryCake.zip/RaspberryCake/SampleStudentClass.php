<?php

include_once "SamplePersonClass.php";

/**
 * SampleStudentClass short summary.
 *
 * Extend the Person classSampleStudentClass description.
 *
 * @version 1.0
 * @author Michael
 */
class SampleStudentClass extends SamplePersonClass
{
   
    public $GPA = "1.0";

}

?>